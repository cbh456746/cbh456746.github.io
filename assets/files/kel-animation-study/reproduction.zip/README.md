# KEL image-to-video study: reviewed reproduction materials

This is a failed-target research artifact, not a validated cinematic production preset.

## Contents
- `inputs/`: eight selected AI keyframes, exported without metadata. Decoded RGB pixels are preserved.
- `workflows/production/`: fourteen actual generation graphs. `workflows/preflight/`: four earlier feasibility trials.
- `image-prompts/`: nine recorded image-generation instructions from keyframe expansion/correction.
- `runs.json`: full video prompts and parameters, separated by phase and final selection.
- `experiment.json`: software/model hashes, input pixel hashes, output/evaluation scope.
- `edit-selection.json`: the nine selected frame ranges, at 24 fps. `start` is zero-based and `count` is the number kept.

## Repeating a generation
1. Install ComfyUI locally using its official instructions and obtain the named public models from the source repositories listed in `experiment.json`.
2. Copy the eight `inputs/` PNG files into ComfyUI's input directory, retaining their filenames.
3. Submit one JSON graph from `workflows/` as the `prompt` field of a request to your own local ComfyUI `/prompt` endpoint.
4. Review `/history/<prompt_id>` and the generated PNG frames. SaveImage writes to `research/kel/` under the local ComfyUI output folder.
5. Review the actual motion before selecting frames. The final movie used short ranges; matching endpoints did not validate the motion between them.

These are API-format graphs, not node-position UI workflow files. Models, an execution environment and inference memory are not included. The negative prompt was recorded in LTX graphs, but CFG=1 uses the conditional prediction in the tested default sampler path; the list is not a hard constraint. The tested LTX sigma schedule is custom and single-pass. This package does not reproduce the complete official multiscale recipe.

Original gameplay, original character/reference artwork, RISE video frames, private logs, credentials, and model weights are not included. The eight supplied input images are AI-generated fan-art research materials. Character/world references belong to Eternal Return; the RISE reference belongs to its original creators. The article distinguishes source references from generated results.

Image-generation tool/model identity and all original reference images are not fully recorded. This package supports retrying the video experiment from the selected keyframes, not guaranteed regeneration of those keyframes or identical videos. The final 1080p movie is an upscale of 1024x576 generations. No improved RISE-level result is claimed.
